# -*- coding: utf-8 -*-
"""
Created on Thu July 16 15:46:06 2018

@author: admin
"""
import numpy as np
from sklearn.datasets import load_iris
from sklearn.neighbors import KNeighborsClassifier

'''
    数据处理
'''
# 数据处理，x增加默认值为1的b偏量，y处理为onehot编码类型
def data_convert(x, y):
    b = np.ones(y.shape)  # 添加全1列向量代表b偏量
    x_b = np.column_stack((b, x))  # b与x矩阵拼接
    K = len(np.unique(y.tolist()))  # 判断y中有几个分类
    eyes_mat = np.eye(K)  # 按分类数生成对角线为1的单位阵
    y_onehot = np.zeros((y.shape[0], K))  # 初始化y的onehot编码矩阵
    for i in range(0, y.shape[0]):
        y_onehot[i] = eyes_mat[y[i]]  # 根据每行y值，更新onehot编码矩阵
    return x_b, y, y_onehot

'''
    DP算法
'''
def densityCluster(samples,k):      # samples 表示整个数据集，k表示要聚成几簇
    # 存当前样本的距离，便于后续计算dc
    distList = []
    dist = np.zeros((len(samples), len(samples)), dtype=float)
    for i in range(len(samples) - 1):
        for j in range(i + 1, len(samples)):
            distance = np.sum(np.abs(samples[i] - samples[j]))
            dist[i, j] = distance
            dist[j, i] = distance
            if (i != j):
                distList.append(distance)

    disMax = max(distList)
    dc = disMax * 0.1
    Dists_threshold = 0.5 * max(dist.sum(axis=1) / len(samples))   # thre = 0.9

    # 计算密度
    rho = np.zeros(len(samples))
    for i in range(len(samples) - 1):
        for j in range(i + 1, len(samples)):
            rho[i] = rho[i] + np.exp(-(dist[i, j] / dc) * (dist[i, j] / dc))
            rho[j] = rho[j] + np.exp(-(dist[i, j] / dc) * (dist[i, j] / dc))
    rho = [item / max(rho) for item in rho]   #存成一个列表
    ordrho = np.flipud(np.argsort(rho))
    # 计算delta
    delta = np.zeros(len(dist))
    master = -1 * np.ones(len(dist), dtype=int)
    # 求最大距离
    delta[ordrho[0]] = disMax

    for ii in range(1, len(samples)):
        delta[ordrho[ii]] = disMax
        for jj in range(0, ii):
            if dist[ordrho[ii], ordrho[jj]] < delta[ordrho[ii]]:
                delta[ordrho[ii]] = dist[ordrho[ii], ordrho[jj]]
                master[ordrho[ii]] = ordrho[jj]
    # 计算优先级
    gamma = np.zeros(len(samples))
    for i in range(len(samples)):
        gamma[i] = rho[i] * delta[i]

    priority = np.flipud(np.argsort(gamma))
    centers = priority[0:k]

    # 根据中心点聚类
    cl = -1 * np.ones(len(samples), dtype=int)
    clusterIndices = np.zeros(len(samples), dtype=int)
    for i in range(k):
        cl[centers[i]] = i

    for i in range(len(samples)):
        if cl[ordrho[i]] == -1:
            cl[ordrho[i]] = cl[master[ordrho[i]]]

    for i in range(len(samples)):
        clusterIndices[i] = centers[cl[i]]

    q = samples[centers[2]]
    return centers, q, dist, dc, Dists_threshold     # 返回centers的index

'''
   产生训练集和测试集
'''
def generate_traintest_data(x,y,centers):
    x_train = x[centers]                     # 训练集的名字叫inputData
    y_train = y[centers]

    #产生测试集
    x_test = np.delete(x, [centers], axis=0)     # 删掉训练集
    y_test = np.delete(y, [centers], axis=0)
    return x_train, y_train, x_test, y_test

'''
    Softmax
'''
def softmax(x_test):
    x_test_max = np.max(x_test)
    x_test = x_test - x_test_max
    return np.exp(x_test) / np.sum(np.exp(x_test), axis=1)

# 逻辑回归中使用梯度下降法求回归系数。逻辑回归和线性回归中原理相同，只不过逻辑回归使用sigmoid作为迭代进化函数。
def gradAscent(x, y, alpha=0.05, max_loop=500):
    # 梯度上升算法
    # alpha=0.05  # 步长
    # max_loop=500 # 循环次数

    weights = np.ones((x.shape[1], y.shape[1]))  # 初始化权回归系数矩阵  系数矩阵的行数为特征矩阵的列数，系数矩阵的列数为分类数目
    print('weights初始化值：', weights)
    for k in range(max_loop):
        # k=0
        h = softmax(x * weights)  # 梯度上升矢量化公式，计算预测值（行向量）。每一个样本产生一个概率行向量
        error = h - y  # 计算每一个样本预测值误差
        weights = weights - alpha * x.T * error  # 根据所有的样本产生的误差调整回归系数
        # print('k:',k,'weights:',weights)
    return weights  # 将矩阵转换为数组，返回回归系数数组


def SoftmaxGD(x, y, alpha=0.005, max_loop=500):
    # 梯度上升算法
    #    alpha=0.05  # 步长
    #    max_loop=500 # 循环次数
    # x = StandardScaler().fit_transform(x) # 数据进行标准化
    m = np.shape(x)[1]  # x的特征数  5列
    n = np.shape(y)[1]  # y的分类数 3类
    weights = np.ones((m, n))  # 权重矩阵

    for k in range(max_loop):
        # k=2
        h = softmax(x * weights)
        error = y - h
        weights = weights + alpha * x.transpose() * error  # 梯度下降算法公式
    # print('k:',k,'weights:',weights.T)
    return weights.getA()

# 对新对象进行预测
def predict(weights, testdata):
    y_hat = softmax(testdata * weights)
    predicted = y_hat.argmax(axis=1).getA()
    return predicted

def accuracy(y, y_hat):
    accuracy = np.sum(y_hat == y)
    accuracy = accuracy *1.0/y.shape[0]
    return accuracy

def informativeness(x_test):
    P22 = softmax(x_test)  # (147,3)
    P2 = P22.T  # (3,147)
    P3 = np.log(P2)  # 这里的log是以e为底的,P3=log P(y=e│x_i;θ)   (3.147)
    P4 = np.multiply(P2, P3)  # 对应位置相乘  (3,147)
    entropy = -sum(P4)  # (1,147)
    return P2, P4, entropy

def representative(dc, dist, centers):
    # 根据窗函数来求
    Dists1 = np.delete(dist, [centers], axis=0)
    Dists2 = np.delete(Dists1, [centers], axis=1)
    p = np.zeros(len(Dists2))
    for i in range(len(Dists2) - 1):
        for j in range(i + 1, len(Dists2)):
            p[i] = p[i] + np.exp(-(Dists2[i, j] / np.sqrt(2) / dc) * (Dists2[i, j] / np.sqrt(2) / dc))
            p[j] = p[j] + np.exp(-(Dists2[i, j] / np.sqrt(2) / dc) * (Dists2[i, j] / np.sqrt(2) / dc))

    represent = p / np.sqrt(2 * np.math.pi * len(Dists2))
    return represent

def getobjectfun(x, y):
    objectfunction = np.zeros(y.shape[0])
    x = np.array(x)
    x = x.T
    for i in range(y.shape[0]):
        objectfunction[i] = x[i] * y[i]

    Ob_fun01 = np.argsort(objectfunction)
    Ob_fun = np.flipud(Ob_fun01)
    return Ob_fun

def max_min01(x):
    x_max = np.max(x)
    x_min = np.min(x)
    x01 = (x - x_min) / (x_max - x_min)
    return x01

if __name__ == "__main__":
    x, y = load_iris(return_X_y=True)
    k = np.max(y) + 1  # DP聚成多少类
    N = np.ceil(len(x) * 0.05)
    N = N.astype(int)  # 浮点型转成int型
    print('N = ', N)
    centers, q, dist, dc, Dists_threshold = densityCluster(x, k)
    x_train, y_train, x_test, y_test = generate_traintest_data(x, y, centers)
    print('centersDP = ', centers)
    print('y_trainlabels', y_train)
    x_train_index = centers

    for numtrain in range(N - 3):
        x_train, y_train = np.mat(x_train), np.mat(y_train).T
        x_test, y_test = np.mat(x_test), np.mat(y_test).T

        x_train, y_train, y_train_onehot = data_convert(x_train, y_train)
        weights1 = SoftmaxGD(x_train, y_train_onehot)

        x_test, y_test, y_test_onehot = data_convert(x_test, y_test)

        y_hat1 = predict(weights1, x_test)
        acc = accuracy(y_test, y_hat1)
        print('Softmax acc = ', acc)

        record = []
        q_label = []

        P2, P4, entropy = informativeness(x_test)
        entropy01 = max_min01(entropy)   # 归一化到[0,1]


        represent = representative(dc, dist, x_train_index)
        represent01 = max_min01(represent)    # 归一化到[0,1]

        Ob_fun = getobjectfun(entropy01, represent01)

        # convert的时候增加了第一列全1，现在删掉x_train的第一列
        x_train = np.delete(x_train, [0], axis=1)
        x_test = np.delete(x_test, [0], axis=1)

        ##以上的Ob_fun存储的是testData里面的index
        for b in range(len(x_test)):
            Dists_g = np.sum(np.abs(x_test[Ob_fun[b]] - q))
            #print('Dists_g = ', Dists_g)
            # print('Dists_threshold', Dists_threshold)
            if Dists_g < Dists_threshold:
                b += b + 1
            else:
                break

        q = x_test[Ob_fun[b]]
        q_label = y_test[Ob_fun[b]]
        print("q =", q)

        #现在我们要找到x_test中的新 q 在整个Data里面的索引
        for i in range(x.shape[0]):
             if (x[i] == q).all():
                 record1 = [i]
                 # print(record1)
                 record.extend(record1)

                 while [] in record:
                     record.remove([])
                     # print('record = ', record)

                 print('record = ', record)
             else:
                 i += i + 1

        x_train_index = np.append(x_train_index, record)
        print(x_train_index)
        x_train, y_train, x_test, y_test = generate_traintest_data(x, y, x_train_index)

        numtrain = x_train.shape[0]
        #print('numtrain', numtrain)
        print('y_train =', y_train)

    '''
        kNN分类
    '''
    KNN = KNeighborsClassifier(n_neighbors=2, weights='distance', metric='euclidean')
    KNN = KNN.fit(x_train, y_train)
    y_hat2 = KNN.predict(x_test)

    # 调用该对象的打分方法，计算出准确率
    #acc = KNN.score(x_train, y_train, sample_weight = None)

    #一般的比较Accuracy
    acc = accuracy(y_test, y_hat2)
    print('kNN Accuracy =', acc)









