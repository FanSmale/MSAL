function [figure,h1]=figure_center1(center)

dataDecision = 'D:\��ӣ߮\data\dataxls\SeedsDecision.xlsx';
[dataDecision,~] = xlsread(dataDecision);
[m,l2]=size(dataDecision);
X = dataDecision(:,1:l2-1);
Y = dataDecision(:,l2);    
k = max(dataDecision(:,l2));  % �������
N = 6;
Dists = manhattanDist(X, X);

% ������� cl
for i=1:m
    cl(i)=dataDecision(i,l2);
end

Y1 = mdscale(Dists, 2, 'criterion','metricsstress');
% cmap=colormap;    % ��ͬ�Ĵ��ò�ͬ����ɫ��ʾ
o =['or'; 'sk'; '<r'; '+m';'+y';'^k'; 'sb';'>g'; '.y';'*m';'ok';'<b';'>k';'^y';'oc';];

for i=1:N      
    center1Lables(i) = Y(center(i));
    center1Instances(i) = center(i);
    center1(i,1) = Y1(center1Instances(i),1);
    center1(i,2) = Y1(center1Instances(i),2);
end

for i=1:m
    A(i,1)=0.;
    A(i,2)=0.;
end

for i=1:k
    nn=0;
    ic=int8((i*64.)/(k*1.));
    for j=1:m
        if (cl(j)==i)
            nn=nn+1;
            A(nn,1)=Y1(j,1);
            A(nn,2)=Y1(j,2);
        end
    end
    hold on
    %     figure=plot(A(1:nn,1),A(1:nn,2),'o','MarkerSize',3,'MarkerFaceColor',cmap(ic,:),'MarkerEdgeColor','k');
    %     h1=plot(center1(:,1),center1(:,2), 'r*','LineWidth',3);
    figure = plot(A(1:nn,1),A(1:nn,2),o(i),'MarkerSize',7);
    h1 = plot(center1(:,1),center1(:,2), 'kp','LineWidth',3);
end
end